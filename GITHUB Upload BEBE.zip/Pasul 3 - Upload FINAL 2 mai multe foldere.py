import os
import shutil
import subprocess
import requests
from pathlib import Path
import time
import uuid

# Configurație
BASE_DIR = r"e:\Carte\BB\17 - Site Leadership (Celelalte)\ThemeForest\main-file - TOATE CREATIVE STUDIO"
USERNAME = "me-suzy"
TOKEN = "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"  # Token GitHub activ
HEADERS = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

# Director temporar pentru lucru
WORK_DIR = r"D:\temp_github_upload"

# Căi Git
GIT_PATHS = [
    r"D:\Program Files\Git\bin\git.exe",  # Calea ta detectată
    r"C:\Program Files\Git\bin\git.exe",
    r"C:\Program Files (x86)\Git\bin\git.exe",
    "git"
]

def find_git():
    """Găsește calea către Git"""
    for git_path in GIT_PATHS:
        try:
            result = subprocess.run([git_path, "--version"],
                                  capture_output=True, timeout=5)
            if result.returncode == 0:
                return git_path
        except:
            continue
    return None

def delete_github_repo(repo_name):
    """Șterge repository de pe GitHub dacă există"""
    url = f"https://api.github.com/repos/{USERNAME}/{repo_name}"
    response = requests.delete(url, headers=HEADERS)

    if response.status_code == 204:
        print(f"   🗑️ Repository {repo_name} șters")
        return True
    elif response.status_code == 404:
        print(f"   ℹ️  Repository {repo_name} nu există")
        return True
    else:
        print(f"   ⚠️  Nu pot șterge {repo_name}: {response.status_code}")
        return False

def create_github_repo(repo_name, force_recreate=False):
    """Creează repository pe GitHub"""
    full_repo_name = f"template-{repo_name}"

    if force_recreate:
        delete_github_repo(full_repo_name)
        time.sleep(1)  # Așteaptă ca GitHub să proceseze

    url = "https://api.github.com/user/repos"
    data = {
        "name": full_repo_name,
        "description": f"ThemeForest Template: {repo_name.title().replace('-', ' ')}",
        "private": False,
        "has_issues": True,
        "has_projects": False,
        "has_wiki": False
    }

    response = requests.post(url, json=data, headers=HEADERS)

    if response.status_code == 201:
        print(f"✅ Repository {full_repo_name} creat pe GitHub")
        return True
    elif response.status_code == 422:
        error_msg = response.json().get('message', '')
        if 'already exists' in error_msg:
            print(f"⚠️  Repository {full_repo_name} există deja - folosesc existent")
            return True
        else:
            print(f"❌ Eroare 422: {response.json()}")
            return False
    else:
        print(f"❌ Eroare la crearea {full_repo_name}: {response.json()}")
        return False

def cleanup_directory(directory):
    """Curăță directorul cu forță"""
    if os.path.exists(directory):
        try:
            # Oprește orice proces Git
            try:
                subprocess.run(["taskkill", "/F", "/IM", "git.exe"],
                              capture_output=True, timeout=5)
            except:
                pass

            time.sleep(1)
            shutil.rmtree(directory, ignore_errors=True)

            if os.path.exists(directory):
                os.system(f'rmdir /S /Q "{directory}"')

        except Exception as e:
            print(f"   ⚠️  Cleanup warning: {e}")

def get_template_folders():
    """Găsește toate template-urile cu foldere și HTML-uri"""
    templates = []

    for item in os.listdir(BASE_DIR):
        folder_path = os.path.join(BASE_DIR, item)
        html_file = os.path.join(BASE_DIR, f"index-{item}.html")

        if os.path.isdir(folder_path) and os.path.exists(html_file):
            templates.append(item)

    return sorted(templates)

def select_single_template(templates):
    """Selecție îmbunătățită pentru un singur template"""
    print(f"\n📋 SELECTARE TEMPLATE INDIVIDUAL:")
    print("-" * 40)

    # Afișează lista completă numerotată
    for i, template in enumerate(templates, 1):
        print(f"   {i:2d}. {template}")

    print(f"\n🎯 OPȚIUNI SELECȚIE:")
    print("   • Introdu NUMĂRUL template-ului (ex: 15)")
    print("   • Sau introdu NUMELE complet (ex: agency)")
    print("   • Sau 'list' pentru a vedea din nou lista")

    while True:
        choice = input(f"\n❓ Alege template-ul (1-{len(templates)} sau nume): ").strip()

        if choice.lower() == 'list':
            # Afișează din nou lista
            print(f"\n📋 TEMPLATE-URI DISPONIBILE:")
            for i, template in enumerate(templates, 1):
                print(f"   {i:2d}. {template}")
            continue

        # Încearcă să parseze ca număr
        try:
            template_index = int(choice) - 1
            if 0 <= template_index < len(templates):
                selected_template = templates[template_index]
                print(f"✅ Selectat: {selected_template} (#{template_index + 1})")
                return selected_template
            else:
                print(f"❌ Numărul trebuie să fie între 1 și {len(templates)}")
                continue
        except ValueError:
            pass

        # Încearcă ca nume exact
        if choice in templates:
            template_index = templates.index(choice) + 1
            print(f"✅ Selectat: {choice} (#{template_index})")
            return choice

        # Încearcă căutare parțială (case insensitive)
        matches = [t for t in templates if choice.lower() in t.lower()]
        if len(matches) == 1:
            selected_template = matches[0]
            template_index = templates.index(selected_template) + 1
            print(f"✅ Găsit: {selected_template} (#{template_index})")
            return selected_template
        elif len(matches) > 1:
            print(f"❌ Multe rezultate găsite pentru '{choice}':")
            for i, match in enumerate(matches[:5], 1):
                template_index = templates.index(match) + 1
                print(f"   {template_index}. {match}")
            if len(matches) > 5:
                print(f"   ... și încă {len(matches) - 5} rezultate")
            print("💡 Fii mai specific sau folosește numărul")
            continue
        else:
            print(f"❌ Template-ul '{choice}' nu a fost găsit")
            print("💡 Folosește 'list' pentru a vedea toate opțiunile")
            continue

def create_readme(template_dir, template_name):
    """Creează README pentru template"""
    template_title = template_name.title().replace('-', ' ')

    readme_content = f"""# {template_title} Template

## 🎨 ThemeForest Template: {template_title}

### 📁 Structura Proiectului
```
template-{template_name}/
├── index.html          # Pagina principală
├── assets/             # Resurse specifice template-ului
│   ├── css/           # Stiluri CSS custom
│   ├── js/            # JavaScript custom
│   ├── images/        # Imagini și media
│   └── ...
└── vendor/             # Dependențe comune (Bootstrap, jQuery, etc.)
    ├── bootstrap/
    ├── jquery/
    ├── css/
    ├── js/
    └── ...
```

### 🚀 Cum să Folosești

1. **Descarcă repository-ul:**
   ```bash
   git clone https://github.com/{USERNAME}/template-{template_name}.git
   cd template-{template_name}
   ```

2. **Deschide template-ul:**
   - Deschide `index.html` în browser pentru preview
   - Sau folosește un server local pentru dezvoltare

3. **Personalizează:**
   - Modifică fișierele din `assets/` pentru customizare
   - Editează `index.html` pentru conținut

### ✨ Features

- ✅ Responsive design (funcționează pe toate dispozitivele)
- ✅ Cross-browser compatibility
- ✅ Bootstrap framework
- ✅ jQuery integration
- ✅ Clean, modern code
- ✅ Easy to customize

### 🔧 Tehnologii

- **HTML5** - Markup semantic
- **CSS3** - Stiluri moderne
- **JavaScript/jQuery** - Interactivitate
- **Bootstrap** - Framework responsive

### 📱 Browser Support

- ✅ Chrome, Firefox, Safari, Edge (latest versions)
- ✅ Mobile browsers

### 📄 Licență

Template original de la ThemeForest. Respectă licența originală pentru utilizare comercială.

### 🔗 Demo

Deschide `index.html` pentru a vedea template-ul în acțiune.

---
**📤 Uploaded automatically from ThemeForest collection**
**⭐ Star this repo if you find it useful!**
"""

    with open(os.path.join(template_dir, "README.md"), "w", encoding="utf-8") as f:
        f.write(readme_content)

def create_complete_template(template_name, git_path, force_recreate=False):
    """Creează un template complet cu toate dependențele"""
    print(f"\n🔄 Procesez template: {template_name}")

    unique_id = str(uuid.uuid4())[:8]
    template_dir = os.path.join(WORK_DIR, f"template-{template_name}-{unique_id}")

    try:
        # Curăță și creează directorul
        cleanup_directory(template_dir)
        os.makedirs(template_dir, exist_ok=True)

        # 1. Copiază folderul template-ului
        source_folder = os.path.join(BASE_DIR, template_name)
        if os.path.exists(source_folder):
            shutil.copytree(source_folder, os.path.join(template_dir, "assets"))
            print(f"   📂 Copiat folder: {template_name}/")

        # 2. Copiază HTML-ul principal
        source_html = os.path.join(BASE_DIR, f"index-{template_name}.html")
        if os.path.exists(source_html):
            shutil.copy2(source_html, os.path.join(template_dir, "index.html"))
            print(f"   📄 Copiat HTML: index-{template_name}.html → index.html")

        # 3. Copiază vendor
        vendor_source = os.path.join(BASE_DIR, "vendor")
        if os.path.exists(vendor_source):
            shutil.copytree(vendor_source, os.path.join(template_dir, "vendor"))
            print(f"   📦 Copiat vendor/")

        # 4. Creează README
        create_readme(template_dir, template_name)
        print(f"   📝 README.md creat")

        # 5. Upload pe GitHub
        success = upload_to_github(template_dir, template_name, git_path, force_recreate)

        # 6. Cleanup
        cleanup_directory(template_dir)

        if success:
            print(f"✅ {template_name} - SUCCESS!")
            return True
        else:
            print(f"❌ {template_name} - FAILED!")
            return False

    except Exception as e:
        print(f"❌ Eroare la {template_name}: {e}")
        cleanup_directory(template_dir)
        return False

def upload_to_github(template_dir, template_name, git_path, force_recreate=False):
    """Upload template pe GitHub"""
    repo_name = f"template-{template_name}"

    # Creează repo pe GitHub
    if not create_github_repo(template_name, force_recreate):
        return False

    # Schimbă directorul curent
    original_dir = os.getcwd()

    try:
        os.chdir(template_dir)

        print(f"   🔧 Configurez Git local...")

        # Configurează Git local pentru acest repository
        subprocess.run([git_path, "init"],
                      check=True, capture_output=True, timeout=30)
        subprocess.run([git_path, "config", "user.name", "me-suzy"],
                      check=True, capture_output=True, timeout=10)
        subprocess.run([git_path, "config", "user.email", "me-suzy@users.noreply.github.com"],
                      check=True, capture_output=True, timeout=10)

        print(f"   📤 Upload fișiere...")

        # Adaugă fișierele
        subprocess.run([git_path, "add", "."],
                      check=True, capture_output=True, timeout=60)

        # Commit
        subprocess.run([git_path, "commit", "-m", f"🎨 Initial upload: {template_name} template\n\n✨ Complete ThemeForest template ready to use\n- Responsive design\n- All dependencies included\n- Professional README"],
                      check=True, capture_output=True, timeout=60)

        # Set branch
        subprocess.run([git_path, "branch", "-M", "main"],
                      check=True, capture_output=True, timeout=10)

        # Remote
        repo_url = f"https://{TOKEN}@github.com/{USERNAME}/{repo_name}.git"
        subprocess.run([git_path, "remote", "add", "origin", repo_url],
                      check=True, capture_output=True, timeout=10)

        # Push
        print(f"   🚀 Push pe GitHub...")
        subprocess.run([git_path, "push", "-u", "origin", "main"],
                      check=True, capture_output=True, timeout=120)

        print(f"   🔗 URL: https://github.com/{USERNAME}/{repo_name}")
        return True

    except subprocess.CalledProcessError as e:
        print(f"   ❌ Git error: {e}")
        if e.stderr:
            print(f"   📄 Error details: {e.stderr.decode()}")
        return False
    except subprocess.TimeoutExpired:
        print(f"   ❌ Timeout - operația a durat prea mult")
        return False
    finally:
        # Revine la directorul original
        try:
            os.chdir(original_dir)
        except:
            pass

def main():
    print("🚀 THEMEFOREST TEMPLATES - VERSIUNE FINALĂ COMPLETĂ")
    print("=" * 60)
    print("📁 Upload complet template-uri pe GitHub")
    print("🎯 Cu Git configurat și opțiuni îmbunătățite")
    print()

    # Găsește Git
    git_path = find_git()
    if not git_path:
        print("❌ Git nu a fost găsit!")
        print("💡 Rulează script-ul de configurare Git mai întâi")
        return

    print(f"✅ Git găsit: {git_path}")

    # Creează directorul de lucru
    os.makedirs(WORK_DIR, exist_ok=True)
    print(f"📁 Director de lucru: {WORK_DIR}")

    # Găsește template-urile
    templates = get_template_folders()
    print(f"🔍 Găsite {len(templates)} template-uri complete")

    if not templates:
        print("❌ Nu am găsit template-uri")
        return

    # Afișează preview
    print(f"\n📋 TEMPLATE-URI DISPONIBILE ({len(templates)} total):")
    for i, template in enumerate(templates[:10], 1):
        print(f"   {i:2d}. {template}")
    if len(templates) > 10:
        print(f"   ... și încă {len(templates) - 10} template-uri")

    # Opțiuni
    print(f"\n🎛️  OPȚIUNI:")
    print("   1. Toate template-urile")
    print("   2. Doar primele 3 (test rapid)")
    print("   3. Un singur template (selecție îmbunătățită)")
    print("   4. Interval personalizat")
    print("   5. Șterge și recrează repository-uri existente")
    print("   6. Anulează")

    choice = input("\n❓ Alege opțiunea (1-6): ").strip()

    force_recreate = False

    if choice == "2":
        templates = templates[:3]
        print(f"🧪 Test rapid: procesez {len(templates)} template-uri")
    elif choice == "3":
        selected_template = select_single_template(templates)
        templates = [selected_template]
        print(f"🧪 Test individual: template '{selected_template}'")
    elif choice == "4":
        try:
            start = int(input(f"Start (1-{len(templates)}): ")) - 1
            end = int(input(f"End (1-{len(templates)}): "))
            templates = templates[start:end]
            print(f"📝 Interval: template-urile {start+1}-{end}")
        except:
            templates = templates[:3]
            print("❌ Interval invalid, folosesc primele 3")
    elif choice == "5":
        force_recreate = True
        print("🔄 Mod recreare: repository-urile existente vor fi șterse și recreate")
    elif choice == "6":
        print("⏹️  Anulat.")
        return

    # Confirmă
    response = input(f"\n❓ Continui cu {len(templates)} template-uri? (y/N): ").lower()
    if response != 'y':
        print("⏹️  Anulat.")
        return

    # Procesează template-urile
    print(f"\n🚀 ÎNCEP UPLOAD-UL FINAL...")
    print("=" * 60)

    start_time = time.time()
    success_count = 0
    failed_templates = []

    for i, template in enumerate(templates, 1):
        print(f"\n[{i}/{len(templates)}] 📤 {template.upper()}")
        print("-" * 40)

        if create_complete_template(template, git_path, force_recreate):
            success_count += 1
        else:
            failed_templates.append(template)

        # Progres
        progress = (i / len(templates)) * 100
        elapsed = time.time() - start_time
        print(f"📊 Progres: {progress:.1f}% | Timp: {elapsed/60:.1f} min | Success: {success_count}/{i}")

        # Pauză între template-uri
        if i < len(templates):
            print("   ⏳ Pauză 3 secunde...")
            time.sleep(3)

    # Cleanup final
    cleanup_directory(WORK_DIR)

    # Raport final
    total_time = time.time() - start_time
    print(f"\n🎉 UPLOAD COMPLET!")
    print("=" * 60)
    print(f"📊 STATISTICI FINALE:")
    print(f"   ✅ Template-uri reușite: {success_count}")
    print(f"   ❌ Template-uri eșuate: {len(failed_templates)}")
    print(f"   📈 Rata de succes: {(success_count/len(templates)*100):.1f}%")
    print(f"   ⏱️  Timp total: {total_time/60:.1f} minute")
    print(f"   🔗 Profile: https://github.com/{USERNAME}?tab=repositories")

    if failed_templates:
        print(f"\n❌ TEMPLATE-URI EȘUATE:")
        for template in failed_templates:
            print(f"   - {template}")

    print(f"\n🎯 COMPLETAT!")
    print("   1. Verifică repository-urile pe GitHub")
    print("   2. Testează template-urile")
    print("   3. Configurează GitHub Pages pentru demo-uri (opțional)")

if __name__ == "__main__":
    main()