import requests

# Configurație
USERNAME = "me-suzy"
TOKEN = "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"  # Token GitHub activ

def test_github_auth():
    """Testează autentificarea GitHub"""
    print("🔐 Testez autentificarea GitHub...")

    # Test 1: Verifică user-ul autentificat
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

    response = requests.get("https://api.github.com/user", headers=headers)

    if response.status_code == 200:
        user_data = response.json()
        print(f"✅ Autentificare OK!")
        print(f"   👤 User: {user_data['login']}")
        print(f"   📧 Email: {user_data.get('email', 'N/A')}")
        print(f"   🌐 Profile: {user_data['html_url']}")
        return True
    else:
        print(f"❌ Autentificare eșuată!")
        print(f"   Status: {response.status_code}")
        print(f"   Răspuns: {response.text}")
        return False

def test_repo_creation():
    """Testează crearea unui repository de test"""
    print("\n🧪 Testez crearea repository...")

    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

    data = {
        "name": "test-template-upload",
        "description": "Test repository pentru upload templates",
        "private": False
    }

    response = requests.post("https://api.github.com/user/repos", json=data, headers=headers)

    if response.status_code == 201:
        repo_data = response.json()
        print(f"✅ Repository creat cu succes!")
        print(f"   📁 Nume: {repo_data['name']}")
        print(f"   🔗 URL: {repo_data['html_url']}")

        # Șterge repository-ul de test
        delete_url = f"https://api.github.com/repos/{USERNAME}/test-template-upload"
        delete_response = requests.delete(delete_url, headers=headers)
        if delete_response.status_code == 204:
            print(f"   🗑️ Repository de test șters")

        return True
    else:
        print(f"❌ Crearea repository-ului a eșuat!")
        print(f"   Status: {response.status_code}")
        print(f"   Răspuns: {response.json()}")
        return False

def main():
    print("🚀 GitHub API Test Script")
    print("=" * 40)

    if TOKEN == "ghp_xxxxxxxxxxxxxxxxxx":
        print("❌ CONFIGUREAZĂ TOKEN-UL în script!")
        print("   1. Mergi la: https://github.com/settings/tokens")
        print("   2. Generate new token (classic)")
        print("   3. Selectează permisiunea 'repo'")
        print("   4. Copiază token-ul în script")
        return

    # Test autentificare
    if not test_github_auth():
        print("\n💡 Soluții:")
        print("   1. Verifică că token-ul este copiat corect")
        print("   2. Verifică că token-ul are permisiunea 'repo'")
        print("   3. Generează un token nou dacă este necesar")
        return

    # Test creare repository
    if not test_repo_creation():
        print("\n💡 Soluții:")
        print("   1. Token-ul trebuie să aibă permisiunea 'repo'")
        print("   2. Verifică că nu ai atins limita de repository-uri")
        return

    print("\n🎉 Toate testele au trecut!")
    print("✅ Poți rula scriptul principal pentru template-uri!")

if __name__ == "__main__":
    main()