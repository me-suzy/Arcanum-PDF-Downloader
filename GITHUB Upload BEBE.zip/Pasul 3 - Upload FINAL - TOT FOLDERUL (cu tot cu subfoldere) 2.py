import os
import shutil
import subprocess
import requests
import time
from pathlib import Path
from collections import defaultdict
import mimetypes

# Configurație
SOURCE_DIR = r"e:\Carte\BB\17 - Site Leadership\alte\Ionel Balauta\Aryeht\Task 1 - Traduce tot site-ul\Doar Google Web\Andreea\Meditatii\2023\GITHUB Upload BEBE"
USERNAME = "me-suzy"
TOKEN = "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"
REPO_NAME = "Meditatii-2023-Collection"  # Nume repository
WORK_DIR = r"D:\temp_github_upload_meditatii"

# Căi Git
GIT_PATHS = [
    r"D:\Program Files\Git\bin\git.exe",
    r"C:\Program Files\Git\bin\git.exe",
    r"C:\Program Files (x86)\Git\bin\git.exe",
    "git"
]

HEADERS = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

def find_git():
    """Găsește calea către Git"""
    for git_path in GIT_PATHS:
        try:
            result = subprocess.run([git_path, "--version"],
                                  capture_output=True, timeout=5)
            if result.returncode == 0:
                return git_path
        except:
            continue
    return None

def analyze_folder_content(folder_path):
    """Analizează conținutul folderului și creează statistici"""

    file_stats = {
        "total_files": 0,
        "total_folders": 0,
        "total_size": 0,
        "by_extension": defaultdict(int),
        "by_type": defaultdict(int),
        "largest_files": [],
        "folder_structure": [],
        "all_files": []
    }

    print("🔍 Analizez conținutul folderului...")

    for root, dirs, files in os.walk(folder_path):
        # Calculează adâncimea pentru structură
        level = root.replace(folder_path, '').count(os.sep)
        indent = "  " * level
        rel_path = os.path.relpath(root, folder_path)

        if rel_path != ".":
            file_stats["folder_structure"].append(f"{indent}📁 {os.path.basename(root)}/")

        file_stats["total_folders"] += len(dirs)

        for file in files:
            file_path = os.path.join(root, file)
            file_size = os.path.getsize(file_path)
            file_ext = Path(file).suffix.lower()

            # Statistici generale
            file_stats["total_files"] += 1
            file_stats["total_size"] += file_size
            file_stats["by_extension"][file_ext if file_ext else "no_extension"] += 1

            # Determinarea tipului de fișier
            mime_type, _ = mimetypes.guess_type(file_path)
            if mime_type:
                main_type = mime_type.split('/')[0]
                file_stats["by_type"][main_type] += 1
            else:
                file_stats["by_type"]["unknown"] += 1

            # Adaugă la lista completă
            rel_file_path = os.path.relpath(file_path, folder_path)
            file_stats["all_files"].append({
                "name": file,
                "path": rel_file_path,
                "size": file_size,
                "extension": file_ext,
                "type": main_type if mime_type else "unknown"
            })

            # Top fișiere mari
            file_stats["largest_files"].append((file, file_size, rel_file_path))

            # Adaugă la structură
            file_indent = "  " * (level + 1)
            file_stats["folder_structure"].append(f"{file_indent}📄 {file}")

    # Sortează fișierele mari
    file_stats["largest_files"] = sorted(file_stats["largest_files"],
                                        key=lambda x: x[1], reverse=True)[:10]

    return file_stats

def format_size(bytes_size):
    """Formatează dimensiunea în format human-readable"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.1f} TB"

def create_comprehensive_readme(stats):
    """Creează README complet bazat pe analiza folderului"""

    total_size_formatted = format_size(stats["total_size"])

    readme_content = f"""# 📚 Meditatii 2023 Collection

## 📖 Overview

Această colecție conține materiale educaționale și resurse pentru meditații din anul 2023. Repository-ul a fost creat automat și include o analiză completă a conținutului.

## 📊 Statistici Generale

- 📁 **Total foldere**: {stats["total_folders"]}
- 📄 **Total fișiere**: {stats["total_files"]}
- 💾 **Dimensiune totală**: {total_size_formatted}
- 📅 **Data upload**: {time.strftime('%Y-%m-%d %H:%M:%S')}

## 🗂️ Tipuri de Fișiere

### După Extensie
"""

    # Adaugă statistici după extensie
    for ext, count in sorted(stats["by_extension"].items(), key=lambda x: x[1], reverse=True):
        ext_display = ext if ext != "no_extension" else "(fără extensie)"
        readme_content += f"- **{ext_display}**: {count} fișiere\n"

    readme_content += "\n### După Tip Conținut\n"

    # Adaugă statistici după tip
    type_icons = {
        "text": "📝",
        "image": "🖼️",
        "video": "🎬",
        "audio": "🎵",
        "application": "📦",
        "unknown": "❓"
    }

    for file_type, count in sorted(stats["by_type"].items(), key=lambda x: x[1], reverse=True):
        icon = type_icons.get(file_type, "📄")
        readme_content += f"- {icon} **{file_type.title()}**: {count} fișiere\n"

    # Fișiere mari
    if stats["largest_files"]:
        readme_content += "\n## 📏 Fișiere Mari (Top 10)\n\n"
        for i, (filename, size, path) in enumerate(stats["largest_files"], 1):
            size_formatted = format_size(size)
            readme_content += f"{i}. **{filename}** - {size_formatted}\n   📂 `{path}`\n\n"

    # Structura folderului
    readme_content += f"""## 🗂️ Structura Repository-ului

```
Meditatii-2023-Collection/
├── 📚 docs/                     # Documentație și ghiduri
│   ├── FILE_LIST.md            # Lista completă de fișiere
│   └── USAGE.md                # Ghid de utilizare
├── 📄 README.md                # Acest fișier
├── 🔧 .gitignore               # Fișiere ignorate de Git
└── content/                    # Conținutul original
"""

    # Adaugă primele câteva niveluri din structură
    readme_content += "    "
    for line in stats["folder_structure"][:20]:  # Primele 20 de linii
        readme_content += f"{line}\n    "

    if len(stats["folder_structure"]) > 20:
        readme_content += f"    ... și încă {len(stats['folder_structure']) - 20} elemente\n"

    readme_content += """```

📋 Pentru lista completă de fișiere, vezi [docs/FILE_LIST.md](docs/FILE_LIST.md)

## 🚀 Cum să Folosești

### 1. Clonează Repository-ul
```bash
git clone https://github.com/me-suzy/Meditatii-2023-Collection.git
cd Meditatii-2023-Collection
```

### 2. Explorează Conținutul
```bash
# Vezi structura
tree content/

# Sau navighează în folderele de interes
cd content/
```

### 3. Documentația
- 📖 **README.md** - Acest ghid general
- 📋 **docs/FILE_LIST.md** - Lista completă de fișiere
- 🎯 **docs/USAGE.md** - Ghid detaliat de utilizare

## 📁 Organizare

Conținutul este organizat în folderul `content/` pentru a păstra structura originală. Documentația și configurația sunt în rădăcina repository-ului.

## ✨ Features

- ✅ **Backup complet** al materialelor de meditații
- ✅ **Structură păstrată** identică cu originalul
- ✅ **Documentație automată** generată
- ✅ **Statistici detaliate** despre conținut
- ✅ **Gitignore configurat** pentru tipuri irelevante
- ✅ **Organizare profesională**

## 📄 Licență

Materialele educaționale din această colecție sunt proprietatea autorilor respectivi. Repository-ul servește ca backup și organizare.

## 🤝 Contribuții

Pentru modificări sau îmbunătățiri, te rog să:
1. Faci fork la repository
2. Creezi o branch pentru modificări
3. Trimiți un pull request

## 📞 Contact

Pentru întrebări despre conținut sau repository, contactează proprietarul.

---

**📤 Repository creat automat cu analiză completă**
**⭐ Star this repo if you find it useful!**
"""

    return readme_content

def create_file_list_documentation(stats):
    """Creează documentația completă cu lista fișierelor"""

    # Sortează fișierele după cale
    sorted_files = sorted(stats["all_files"], key=lambda x: x["path"])

    file_list_content = f"""# 📋 Lista Completă de Fișiere

Această listă conține toate fișierele din colecția Meditatii 2023, organizate pentru o navigare ușoară.

## 📊 Rezumat

- **Total fișiere**: {stats["total_files"]}
- **Dimensiune totală**: {format_size(stats["total_size"])}
- **Generat**: {time.strftime('%Y-%m-%d %H:%M:%S')}

## 📁 Lista Fișierelor

### Organizare după Locație

"""

    # Grupează fișierele după folder
    files_by_folder = defaultdict(list)
    for file_info in sorted_files:
        folder = os.path.dirname(file_info["path"])
        if not folder:
            folder = "📁 Root"
        else:
            folder = f"📁 {folder}"
        files_by_folder[folder].append(file_info)

    # Adaugă fiecare folder și fișierele sale
    for folder, files in sorted(files_by_folder.items()):
        file_list_content += f"\n#### {folder}\n\n"

        for file_info in files:
            size_formatted = format_size(file_info["size"])
            type_icon = {
                "text": "📝",
                "image": "🖼️",
                "video": "🎬",
                "audio": "🎵",
                "application": "📦",
                "unknown": "❓"
            }.get(file_info["type"], "📄")

            file_list_content += f"- {type_icon} **{file_info['name']}** ({size_formatted})\n"
            if file_info["extension"]:
                file_list_content += f"  - Extensie: `{file_info['extension']}`\n"
            file_list_content += f"  - Tip: {file_info['type']}\n"
            file_list_content += f"  - Cale: `{file_info['path']}`\n\n"

    file_list_content += """
## 🔍 Căutare și Filtrare

Pentru a găsi rapid fișiere specifice, poți folosi:

- **Ctrl+F** în browser pentru căutare în această pagină
- **grep** în terminal pentru căutări avansate
- **find** pentru căutări după tip sau dimensiune

### Exemple Comenzi

```bash
# Găsește toate fișierele .pdf
find content/ -name "*.pdf"

# Găsește fișiere mari (>10MB)
find content/ -size +10M

# Găsește fișiere modificate recent
find content/ -mtime -7
```

---

🔙 [Înapoi la README principal](../README.md)
"""

    return file_list_content

def create_usage_documentation():
    """Creează ghidul de utilizare"""

    usage_content = """# 🎯 Ghid de Utilizare - Meditatii 2023 Collection

## 📖 Introducere

Acest ghid te ajută să navighezi și să folosești eficient colecția de materiale pentru meditații din 2023.

## 🗂️ Structura Repository-ului

```
Meditatii-2023-Collection/
├── content/                    # Toate materialele originale
│   ├── [folderele originale]  # Structura păstrată exact
│   └── [fișierele originale]  # Toate fișierele originale
├── docs/                      # Documentația
│   ├── FILE_LIST.md          # Lista detaliată fișiere
│   └── USAGE.md              # Acest ghid
├── README.md                 # Prezentare generală
└── .gitignore                # Configurare Git

```

## 🚀 Cum să Începi

### 1. Descarcă Repository-ul

```bash
# Clonează întreg repository-ul
git clone https://github.com/me-suzy/Meditatii-2023-Collection.git

# Sau descarcă doar conținutul (fără Git)
# Click pe "Code" > "Download ZIP" pe GitHub
```

### 2. Navighează în Conținut

```bash
# Intră în folder
cd Meditatii-2023-Collection

# Explorează structura
ls -la content/

# Pentru Windows
dir content\
```

### 3. Găsește Ce Cauți

- **Pentru prezentare generală**: citește `README.md`
- **Pentru lista completă**: vezi `docs/FILE_LIST.md`
- **Pentru găsire rapidă**: folosește căutarea în browser (Ctrl+F)

## 🔍 Căutare și Organizare

### Căutare după Tip Fișier

```bash
# Găsește toate PDF-urile
find content/ -name "*.pdf" -type f

# Găsește toate imaginile
find content/ -name "*.jpg" -o -name "*.png" -o -name "*.gif"

# Găsește toate documentele text
find content/ -name "*.txt" -o -name "*.doc" -o -name "*.docx"
```

### Căutare după Dimensiune

```bash
# Fișiere mari (>10MB)
find content/ -size +10M

# Fișiere mici (<1MB)
find content/ -size -1M
```

### Căutare după Conținut

```bash
# Caută text în fișiere (Linux/Mac)
grep -r "cuvant_cautat" content/

# Pentru Windows cu PowerShell
Select-String -Path "content\*" -Pattern "cuvant_cautat" -Recurse
```

## 📚 Tipuri de Materiale

Bazat pe analiza automată, colecția conține:

### 📝 Documente Text
- Fișiere .txt, .doc, .docx
- Notițe și materiale scrise
- Planuri de lecții

### 🖼️ Materiale Vizuale
- Imagini explicative
- Diagrame și scheme
- Screenshots

### 📦 Alte Formate
- Arhive compresate
- Fișiere de backup
- Resurse diverse

## 🛠️ Unelte Recomandate

### Pentru Vizualizare
- **Text**: Notepad++, VSCode, Sublime Text
- **PDF**: Adobe Reader, SumatraPDF
- **Imagini**: IrfanView, PhotoViewer
- **Office**: Microsoft Office, LibreOffice

### Pentru Organizare
- **File Explorer** (Windows) sau **Finder** (Mac)
- **Total Commander** pentru navigare avansată
- **Everything** pentru căutare rapidă (Windows)

### Pentru Backup
- **Git** pentru versionare
- **rsync** pentru sincronizare
- **7zip** pentru arhivare

## ⚡ Tips și Trucuri

### 1. Navigare Rapidă
- Folosește `Ctrl+F` pentru căutare în documentație
- Creează shortcuts către folderele folosite frecvent
- Folosește tab completion în terminal

### 2. Organizare Personală
- Creează propriile note în folderul personal
- Folosește tags sau labels pentru categorisire
- Menține o structură consistentă

### 3. Backup și Sync
- Clone repository-ul periodic pentru backup
- Folosește `git pull` pentru updates
- Consideră sync cu cloud storage

## 🔄 Actualizări și Mentenanță

### Verifică Actualizări
```bash
# Verifică dacă sunt schimbări noi
git fetch origin

# Descarcă actualizările
git pull origin main
```

### Contribuie cu Îmbunătățiri
1. Fork repository-ul
2. Fă modificările necesare
3. Trimite pull request

## ❓ Întrebări Frecvente

**Q: Cum găsesc rapid un anumit material?**
A: Folosește `docs/FILE_LIST.md` și căutarea în browser (Ctrl+F).

**Q: Pot modifica conținutul?**
A: Da, dar recomand să faci backup înainte și să folosești Git pentru tracking.

**Q: Ce fac dacă găsesc erori?**
A: Raportează prin GitHub Issues sau contactează proprietarul.

**Q: Cum organizez materialele pentru uz personal?**
A: Creează folderul tău de work separate de `content/` pentru a evita conflictele.

## 📞 Suport

Pentru probleme sau întrebări:
- Verifică documentația din `docs/`
- Caută în GitHub Issues
- Contactează proprietarul repository-ului

---

🔙 [Înapoi la README principal](../README.md) | 📋 [Vezi lista fișierelor](FILE_LIST.md)
"""

    return usage_content

def create_gitignore():
    """Creează .gitignore potrivit pentru tipul de conținut"""

    gitignore_content = """# OS generated files
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Windows
desktop.ini
$RECYCLE.BIN/

# IDE and Editor files
.vscode/
.idea/
*.swp
*.swo
*~

# Temporary files
*.tmp
*.temp
*.bak
*.backup
~*

# Log files
*.log
logs/

# Cache directories
.cache/
__pycache__/
*.pyc

# Personal notes (add your own folders here)
personal_notes/
my_work/
temp_work/

# Large binary files that shouldn't be tracked
*.iso
*.dmg
*.exe
*.msi

# Backup files
*.zip.bak
*.rar.bak
*_backup.*

# System files
.fseventsd/
.volumeicon.icns
.com.apple.timemachine.donotpresent
"""

    return gitignore_content

def create_github_repo():
    """Creează repository-ul pe GitHub"""
    url = "https://api.github.com/user/repos"
    data = {
        "name": REPO_NAME,
        "description": "📚 Colecția Meditatii 2023 - Materiale educaționale organizate automat",
        "private": False,
        "has_issues": True,
        "has_projects": False,
        "has_wiki": False
    }

    response = requests.post(url, json=data, headers=HEADERS)

    if response.status_code == 201:
        print(f"✅ Repository {REPO_NAME} creat pe GitHub")
        return True
    elif response.status_code == 422:
        error_msg = response.json().get('message', '')
        if 'already exists' in error_msg:
            print(f"⚠️  Repository {REPO_NAME} există deja")
            choice = input("❓ Ștergi și recreezi repository-ul? (y/N): ").lower()
            if choice == 'y':
                return delete_and_recreate_repo()
            else:
                print("ℹ️  Folosesc repository-ul existent")
                return True
        else:
            print(f"❌ Eroare 422: {response.json()}")
            return False
    else:
        print(f"❌ Eroare la crearea repository-ului: {response.json()}")
        return False

def delete_and_recreate_repo():
    """Șterge și recrează repository-ul"""
    delete_url = f"https://api.github.com/repos/{USERNAME}/{REPO_NAME}"
    response = requests.delete(delete_url, headers=HEADERS)

    if response.status_code == 204:
        print(f"🗑️ Repository {REPO_NAME} șters")
        time.sleep(2)
        return create_github_repo()
    else:
        print(f"❌ Nu pot șterge repository-ul: {response.status_code}")
        return False

def copy_and_organize_content(stats):
    """Copiază și organizează conținutul cu documentația generată"""
    print("📦 Organizez conținutul...")

    # Creează structura
    content_dir = os.path.join(WORK_DIR, "content")
    docs_dir = os.path.join(WORK_DIR, "docs")

    os.makedirs(content_dir, exist_ok=True)
    os.makedirs(docs_dir, exist_ok=True)

    # Copiază conținutul original
    print("   📂 Copiez conținutul original...")
    for item in os.listdir(SOURCE_DIR):
        source_path = os.path.join(SOURCE_DIR, item)
        dest_path = os.path.join(content_dir, item)

        if os.path.isdir(source_path):
            shutil.copytree(source_path, dest_path)
            print(f"   📁 Copiat folder: {item}/")
        else:
            shutil.copy2(source_path, dest_path)
            print(f"   📄 Copiat fișier: {item}")

    # Creează documentația
    print("   📝 Generez documentația...")

    # README principal
    readme_content = create_comprehensive_readme(stats)
    with open(os.path.join(WORK_DIR, "README.md"), "w", encoding="utf-8") as f:
        f.write(readme_content)

    # Lista fișierelor
    file_list_content = create_file_list_documentation(stats)
    with open(os.path.join(docs_dir, "FILE_LIST.md"), "w", encoding="utf-8") as f:
        f.write(file_list_content)

    # Ghidul de utilizare
    usage_content = create_usage_documentation()
    with open(os.path.join(docs_dir, "USAGE.md"), "w", encoding="utf-8") as f:
        f.write(usage_content)

    # .gitignore
    gitignore_content = create_gitignore()
    with open(os.path.join(WORK_DIR, ".gitignore"), "w", encoding="utf-8") as f:
        f.write(gitignore_content)

    print("   ✅ Documentația generată complet!")

def upload_to_github(git_path):
    """Upload repository-ul pe GitHub"""
    print("\n🚀 Upload pe GitHub...")

    original_dir = os.getcwd()

    try:
        os.chdir(WORK_DIR)

        print("   🔧 Configurez Git...")
        subprocess.run([git_path, "init"], check=True, capture_output=True, timeout=30)
        subprocess.run([git_path, "config", "user.name", "me-suzy"], check=True, capture_output=True, timeout=10)
        subprocess.run([git_path, "config", "user.email", "me-suzy@users.noreply.github.com"], check=True, capture_output=True, timeout=10)

        print("   📦 Adaug fișierele...")
        subprocess.run([git_path, "add", "."], check=True, capture_output=True, timeout=180)

        print("   💾 Commit...")
        commit_message = f"""📚 Initial upload: Meditatii 2023 Collection

✨ Features:
- {stats['total_files']} fișiere organizate automat
- {stats['total_folders']} foldere cu structura păstrată
- Documentație completă generată automat
- Analiză detaliată a conținutului

📊 Statistici:
- Dimensiune totală: {format_size(stats['total_size'])}
- Tipuri de fișiere: {len(stats['by_extension'])}
- Organizare profesională cu docs și README

🗂️ Structura:
- content/ - Toate materialele originale
- docs/ - Documentație și ghiduri complete
- README.md - Prezentare cu statistici
- .gitignore - Configurație optimizată

📚 Ready pentru studiu și referință!
"""
        subprocess.run([git_path, "commit", "-m", commit_message], check=True, capture_output=True, timeout=60)

        subprocess.run([git_path, "branch", "-M", "main"], check=True, capture_output=True, timeout=10)

        repo_url = f"https://{TOKEN}@github.com/{USERNAME}/{REPO_NAME}.git"
        subprocess.run([git_path, "remote", "add", "origin", repo_url], check=True, capture_output=True, timeout=10)

        print("   🌐 Push pe GitHub...")
        subprocess.run([git_path, "push", "-u", "origin", "main"], check=True, capture_output=True, timeout=300)

        print(f"   🔗 URL: https://github.com/{USERNAME}/{REPO_NAME}")
        return True

    except subprocess.CalledProcessError as e:
        print(f"   ❌ Git error: {e}")
        return False
    except subprocess.TimeoutExpired:
        print(f"   ❌ Timeout - operația a durat prea mult")
        return False
    finally:
        os.chdir(original_dir)

def cleanup():
    """Curăță directorul de lucru"""
    if os.path.exists(WORK_DIR):
        try:
            shutil.rmtree(WORK_DIR, ignore_errors=True)
            print("🧹 Cleanup complet")
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")

def main():
    print("🚀 MEDITATII 2023 - UPLOAD CU ANALIZĂ AUTOMATĂ")
    print("=" * 60)
    print("📁 Analizează și uploadează folder cu documentație generată")
    print(f"🎯 Sursă: {SOURCE_DIR}")
    print(f"📦 Repository: {REPO_NAME}")
    print()

    # Verifică Git
    git_path = find_git()
    if not git_path:
        print("❌ Git nu a fost găsit!")
        return

    print(f"✅ Git găsit: {git_path}")

    # Verifică directorul sursă
    if not os.path.exists(SOURCE_DIR):
        print(f"❌ Directorul sursă nu există: {SOURCE_DIR}")
        return

    # Analizează conținutul
    global stats
    stats = analyze_folder_content(SOURCE_DIR)

    print(f"📊 Conținut analizat:")
    print(f"   📂 {stats['total_folders']} foldere")
    print(f"   📄 {stats['total_files']} fișiere")
    print(f"   💾 {format_size(stats['total_size'])} dimensiune totală")
    print(f"   🎯 {len(stats['by_extension'])} tipuri de extensii")

    # Confirmă
    response = input(f"\n❓ Continui cu upload-ul și generarea documentației? (y/N): ").lower()
    if response != 'y':
        print("⏹️  Anulat.")
        return

    start_time = time.time()

    try:
        # Creează directorul de lucru
        os.makedirs(WORK_DIR, exist_ok=True)
        print(f"\n📁 Director de lucru: {WORK_DIR}")

        # Creează repository pe GitHub
        if not create_github_repo():
            return

        # Copiază și organizează conținutul
        copy_and_organize_content(stats)

        # Upload pe GitHub
        if upload_to_github(git_path):
            total_time = time.time() - start_time

            print(f"\n🎉 UPLOAD COMPLET!")
            print("=" * 60)
            print(f"✅ Repository creat: https://github.com/{USERNAME}/{REPO_NAME}")
            print(f"⏱️  Timp total: {total_time/60:.1f} minute")
            print(f"📊 Conținut: {stats['total_files']} fișiere, {format_size(stats['total_size'])}")

            print(f"\n🌐 Acces rapid:")
            print(f"   🔗 Repository: https://github.com/{USERNAME}/{REPO_NAME}")
            print(f"   📖 README: https://github.com/{USERNAME}/{REPO_NAME}#readme")
            print(f"   📋 Lista fișiere: https://github.com/{USERNAME}/{REPO_NAME}/blob/main/docs/FILE_LIST.md")
            print(f"   🎯 Ghid utilizare: https://github.com/{USERNAME}/{REPO_NAME}/blob/main/docs/USAGE.md")

        else:
            print("❌ Upload eșuat!")

    except Exception as e:
        print(f"❌ Eroare generală: {e}")

    finally:
        # Cleanup
        cleanup()

if __name__ == "__main__":
    main()