import os
import shutil
import subprocess
import requests
import time

# Configurație
SOURCE_DIR = r"e:\Carte\BB\17 - Site Leadership (Celelalte)\ThemeForest\main-file - TOATE CREATIVE STUDIO"
USERNAME = "me-suzy"
TOKEN = "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"
REPO_NAME = "ThemeForest-Complete-Collection"
WORK_DIR = r"D:\temp_github_upload_unified"

# Căi Git
GIT_PATHS = [
    r"D:\Program Files\Git\bin\git.exe",
    r"C:\Program Files\Git\bin\git.exe",
    r"C:\Program Files (x86)\Git\bin\git.exe",
    "git"
]

HEADERS = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

def find_git():
    """Găsește calea către Git"""
    for git_path in GIT_PATHS:
        try:
            result = subprocess.run([git_path, "--version"],
                                  capture_output=True, timeout=5)
            if result.returncode == 0:
                return git_path
        except:
            continue
    return None

def create_github_repo():
    """Creează repository-ul pe GitHub"""
    url = "https://api.github.com/user/repos"
    data = {
        "name": REPO_NAME,
        "description": "🎨 Complete ThemeForest Template Collection - All Templates in One Repository",
        "private": False,
        "has_issues": True,
        "has_projects": False,
        "has_wiki": True
    }

    response = requests.post(url, json=data, headers=HEADERS)

    if response.status_code == 201:
        print(f"✅ Repository {REPO_NAME} creat pe GitHub")
        return True
    elif response.status_code == 422:
        error_msg = response.json().get('message', '')
        if 'already exists' in error_msg:
            print(f"⚠️  Repository {REPO_NAME} există deja")

            # Întreabă dacă vrea să șteargă și recreeze
            choice = input("❓ Ștergi și recreezi repository-ul? (y/N): ").lower()
            if choice == 'y':
                return delete_and_recreate_repo()
            else:
                print("ℹ️  Folosesc repository-ul existent")
                return True
        else:
            print(f"❌ Eroare 422: {response.json()}")
            return False
    else:
        print(f"❌ Eroare la crearea repository-ului: {response.json()}")
        return False

def delete_and_recreate_repo():
    """Șterge și recrează repository-ul"""
    delete_url = f"https://api.github.com/repos/{USERNAME}/{REPO_NAME}"
    response = requests.delete(delete_url, headers=HEADERS)

    if response.status_code == 204:
        print(f"🗑️ Repository {REPO_NAME} șters")
        time.sleep(2)  # Așteaptă ca GitHub să proceseze
        return create_github_repo()
    else:
        print(f"❌ Nu pot șterge repository-ul: {response.status_code}")
        return False

def create_comprehensive_readme():
    """Creează README complet pentru întregul repository"""

    # Contorizează template-urile pe categorii
    templates_by_category = {
        "Agency & Business": [],
        "Portfolio & Creative": [],
        "E-commerce & Shop": [],
        "Food & Restaurant": [],
        "Medical & Health": [],
        "Education & Learning": [],
        "Real Estate & Property": [],
        "Technology & Apps": [],
        "Sports & Fitness": [],
        "Fashion & Lifestyle": [],
        "Landing Pages": [],
        "Other Specialized": []
    }

    # Categorisează template-urile
    for item in os.listdir(SOURCE_DIR):
        if os.path.isdir(os.path.join(SOURCE_DIR, item)):
            # Categorisire simplă pe baza numelui
            if any(word in item for word in ['agency', 'business', 'corporate', 'consulting']):
                templates_by_category["Agency & Business"].append(item)
            elif any(word in item for word in ['portfolio', 'creative', 'designer', 'studio']):
                templates_by_category["Portfolio & Creative"].append(item)
            elif any(word in item for word in ['shop', 'book-shop', 'food-shop', 'clothing']):
                templates_by_category["E-commerce & Shop"].append(item)
            elif any(word in item for word in ['food', 'restaurant', 'coffee', 'cakes']):
                templates_by_category["Food & Restaurant"].append(item)
            elif any(word in item for word in ['medical', 'dental', 'doctor', 'spa', 'skincare']):
                templates_by_category["Medical & Health"].append(item)
            elif any(word in item for word in ['education', 'university', 'kids']):
                templates_by_category["Education & Learning"].append(item)
            elif any(word in item for word in ['realestate', 'interior', 'architecture']):
                templates_by_category["Real Estate & Property"].append(item)
            elif any(word in item for word in ['app', 'digital', 'startup', 'innovative']):
                templates_by_category["Technology & Apps"].append(item)
            elif any(word in item for word in ['gym', 'yoga', 'cycling', 'football', 'golf', 'surfing']):
                templates_by_category["Sports & Fitness"].append(item)
            elif any(word in item for word in ['fashion', 'jewelry', 'eyewear', 'celebrity', 'model']):
                templates_by_category["Fashion & Lifestyle"].append(item)
            elif 'landing' in item:
                templates_by_category["Landing Pages"].append(item)
            else:
                templates_by_category["Other Specialized"].append(item)

    readme_content = f"""# 🎨 ThemeForest Complete Template Collection

## 📖 Overview

This repository contains a comprehensive collection of **{len([item for item in os.listdir(SOURCE_DIR) if os.path.isdir(os.path.join(SOURCE_DIR, item))])} professional ThemeForest templates** covering various industries and use cases. Each template is fully functional and includes all necessary dependencies.

## 🗂️ Repository Structure

```
ThemeForest-Complete-Collection/
├── templates/                     # Individual template folders
│   ├── agency/                   # Agency template
│   ├── restaurant/               # Restaurant template
│   ├── portfolio/                # Portfolio template
│   └── ... (all other templates)
├── vendor/                       # Shared dependencies (Bootstrap, jQuery, etc.)
├── docs/                        # Documentation and guides
└── README.md                    # This file
```

## 🎯 Template Categories

"""

    # Adaugă categoriile în README
    for category, templates in templates_by_category.items():
        if templates:
            readme_content += f"### {category} ({len(templates)} templates)\n\n"
            for template in sorted(templates):
                # Link către template
                readme_content += f"- **[{template.title().replace('-', ' ')}](./templates/{template}/)** - `{template}`\n"
            readme_content += "\n"

    readme_content += """## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/me-suzy/ThemeForest-Complete-Collection.git
cd ThemeForest-Complete-Collection
```

### 2. Choose a Template
Navigate to any template folder:
```bash
cd templates/agency
```

### 3. Open the Template
- Open `index.html` in your browser for preview
- Or use a local server for development

### 4. Customize
- Edit files in the template folder
- Modify CSS, JS, and HTML as needed
- All dependencies are included

## 📁 Template Structure

Each template follows this structure:
```
template-name/
├── index.html              # Main template file
├── assets/                 # Template-specific resources
│   ├── css/               # Custom styles
│   ├── js/                # Custom scripts
│   ├── images/            # Images and media
│   └── ...
└── (template files vary by design)
```

## 🔧 Shared Dependencies

The `vendor/` folder contains shared libraries used across templates:
- **Bootstrap** - Responsive framework
- **jQuery** - JavaScript library
- **Font Awesome** - Icon fonts
- **Other common libraries**

## ✨ Features

- ✅ **100+ Professional Templates** covering all major industries
- ✅ **Responsive Design** - Works on all devices
- ✅ **Cross-browser Compatible** - Tested on major browsers
- ✅ **Modern Technologies** - HTML5, CSS3, JavaScript
- ✅ **Bootstrap Framework** - Mobile-first approach
- ✅ **Complete Dependencies** - All libraries included
- ✅ **Easy Customization** - Well-organized code
- ✅ **Professional Quality** - Commercial-grade templates

## 🎨 Industries Covered

- 🏢 **Business & Corporate** - Agency, consulting, corporate websites
- 🎯 **Creative & Portfolio** - Designer portfolios, creative agencies
- 🛒 **E-commerce** - Online stores, product showcases
- 🍕 **Food & Dining** - Restaurants, cafes, food delivery
- 🏥 **Healthcare** - Medical practices, dental clinics, spas
- 🎓 **Education** - Schools, universities, learning platforms
- 🏠 **Real Estate** - Property listings, interior design
- 💻 **Technology** - Apps, startups, digital services
- 🏃 **Sports & Fitness** - Gyms, sports clubs, fitness
- 👗 **Fashion & Lifestyle** - Fashion brands, personal sites
- 📄 **Landing Pages** - Product launches, campaigns
- 🔧 **Specialized** - Many other niche industries

## 📱 Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Mobile browsers

## 📄 License

These are original ThemeForest templates. Please respect the original licensing terms for commercial use.

## 🤝 Contributing

This is an archived collection. For template-specific issues or customizations, refer to the original ThemeForest listings.

## 📞 Support

For questions about specific templates:
1. Check the template's original documentation
2. Visit ThemeForest for official support
3. Browse the template files for implementation examples

## 🌟 Star This Repository

If you find this collection useful, please ⭐ star this repository to show your support!

---

**📤 Complete ThemeForest collection uploaded for easy access and backup**
**🎯 Perfect for developers, designers, and agencies looking for quality templates**
"""

    return readme_content

def create_template_index():
    """Creează un index HTML pentru toate template-urile"""

    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ThemeForest Template Collection</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f6f8fa; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #24292e; text-align: center; margin-bottom: 2rem; }
        .templates-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .template-card { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .template-card:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.15); }
        .template-name { font-size: 1.2em; font-weight: 600; margin-bottom: 8px; color: #0366d6; }
        .template-path { font-family: monospace; font-size: 0.9em; color: #586069; margin-bottom: 10px; }
        .view-btn { display: inline-block; padding: 8px 16px; background: #0366d6; color: white; text-decoration: none; border-radius: 4px; font-size: 0.9em; }
        .view-btn:hover { background: #0256cc; }
        .stats { text-align: center; margin: 2rem 0; padding: 20px; background: white; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎨 ThemeForest Template Collection</h1>
        <div class="stats">
            <p><strong>Complete collection of professional templates ready to use</strong></p>
        </div>
        <div class="templates-grid">
"""

    # Adaugă fiecare template
    for item in sorted(os.listdir(SOURCE_DIR)):
        if os.path.isdir(os.path.join(SOURCE_DIR, item)) and item != 'vendor':
            template_name = item.title().replace('-', ' ')
            html_content += f"""
            <div class="template-card">
                <div class="template-name">{template_name}</div>
                <div class="template-path">templates/{item}/</div>
                <a href="templates/{item}/index.html" class="view-btn" target="_blank">View Template</a>
            </div>
"""

    html_content += """
        </div>
    </div>
</body>
</html>
"""
    return html_content

def copy_all_content():
    """Copiază tot conținutul în directorul de lucru"""
    print("📦 Copiez tot conținutul...")

    # Creează directorul de destinație
    dest_dir = os.path.join(WORK_DIR, "templates")
    os.makedirs(dest_dir, exist_ok=True)

    # Contează folderele și fișierele
    folders_count = 0
    files_count = 0

    for item in os.listdir(SOURCE_DIR):
        source_path = os.path.join(SOURCE_DIR, item)

        if os.path.isdir(source_path):
            # Copiază folderul
            dest_path = os.path.join(dest_dir, item)
            if not os.path.exists(dest_path):
                shutil.copytree(source_path, dest_path)
                folders_count += 1
                print(f"   📂 Copiat folder: {item}/")
        else:
            # Copiază fișierul în rădăcina templates
            dest_file = os.path.join(dest_dir, item)
            if not os.path.exists(dest_file):
                shutil.copy2(source_path, dest_file)
                files_count += 1
                print(f"   📄 Copiat fișier: {item}")

    print(f"✅ Copiat {folders_count} foldere și {files_count} fișiere")

    # Creează README
    readme_content = create_comprehensive_readme()
    with open(os.path.join(WORK_DIR, "README.md"), "w", encoding="utf-8") as f:
        f.write(readme_content)
    print("   📝 README.md creat")

    # Creează index HTML
    index_content = create_template_index()
    with open(os.path.join(WORK_DIR, "index.html"), "w", encoding="utf-8") as f:
        f.write(index_content)
    print("   🌐 index.html creat")

    # Creează documentație
    docs_dir = os.path.join(WORK_DIR, "docs")
    os.makedirs(docs_dir, exist_ok=True)

    usage_guide = """# Usage Guide

## How to Use Templates

1. **Choose a template** from the `templates/` folder
2. **Open** the template's `index.html` file
3. **Customize** the content, images, and styling
4. **Deploy** to your web server

## Template Structure

Each template typically contains:
- `index.html` - Main page
- `assets/` - CSS, JS, images
- Additional pages (about.html, contact.html, etc.)

## Common Customizations

- **Colors**: Edit CSS files in `assets/css/`
- **Images**: Replace images in `assets/images/`
- **Content**: Modify HTML files
- **Fonts**: Update font imports in CSS

## Dependencies

Most templates use:
- Bootstrap for responsive design
- jQuery for interactions
- Font Awesome for icons

Dependencies are included in the `vendor/` folder.
"""

    with open(os.path.join(docs_dir, "USAGE.md"), "w", encoding="utf-8") as f:
        f.write(usage_guide)
    print("   📚 Documentație creată")

def upload_to_github(git_path):
    """Upload repository-ul complet pe GitHub"""
    print("\n🚀 Upload pe GitHub...")

    original_dir = os.getcwd()

    try:
        os.chdir(WORK_DIR)

        print("   🔧 Configurez Git...")
        subprocess.run([git_path, "init"], check=True, capture_output=True, timeout=30)
        subprocess.run([git_path, "config", "user.name", "me-suzy"], check=True, capture_output=True, timeout=10)
        subprocess.run([git_path, "config", "user.email", "me-suzy@users.noreply.github.com"], check=True, capture_output=True, timeout=10)

        print("   📄 Creez .gitignore...")
        gitignore_content = """# OS generated files
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# IDE files
.vscode/
.idea/
*.swp
*.swo

# Temporary files
*.tmp
*.temp
"""
        with open(".gitignore", "w") as f:
            f.write(gitignore_content)

        print("   📦 Adaug fișierele...")
        subprocess.run([git_path, "add", "."], check=True, capture_output=True, timeout=180)

        print("   💾 Commit...")
        commit_message = """🎨 Initial upload: Complete ThemeForest Template Collection

✨ Features:
- 100+ professional templates
- All major industries covered
- Responsive design
- Complete dependencies included
- Organized structure with documentation

🗂️ Structure:
- templates/ - Individual template folders
- docs/ - Usage guides and documentation
- index.html - Template browser
- README.md - Comprehensive overview

🚀 Ready to use templates for developers and designers!
"""
        subprocess.run([git_path, "commit", "-m", commit_message], check=True, capture_output=True, timeout=60)

        subprocess.run([git_path, "branch", "-M", "main"], check=True, capture_output=True, timeout=10)

        repo_url = f"https://{TOKEN}@github.com/{USERNAME}/{REPO_NAME}.git"
        subprocess.run([git_path, "remote", "add", "origin", repo_url], check=True, capture_output=True, timeout=10)

        print("   🌐 Push pe GitHub...")
        subprocess.run([git_path, "push", "-u", "origin", "main"], check=True, capture_output=True, timeout=300)

        print(f"   🔗 URL: https://github.com/{USERNAME}/{REPO_NAME}")
        return True

    except subprocess.CalledProcessError as e:
        print(f"   ❌ Git error: {e}")
        return False
    except subprocess.TimeoutExpired:
        print(f"   ❌ Timeout - operația a durat prea mult")
        return False
    finally:
        os.chdir(original_dir)

def cleanup():
    """Curăță directorul de lucru"""
    if os.path.exists(WORK_DIR):
        try:
            shutil.rmtree(WORK_DIR, ignore_errors=True)
            print("🧹 Cleanup complet")
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")

def main():
    print("🚀 THEMEFOREST COLLECTION - REPOSITORY UNIFICAT")
    print("=" * 60)
    print("📁 Upload întreg folder-ul ca un singur repository")
    print(f"🎯 Sursă: {SOURCE_DIR}")
    print(f"📦 Repository: {REPO_NAME}")
    print()

    # Verifică Git
    git_path = find_git()
    if not git_path:
        print("❌ Git nu a fost găsit!")
        return

    print(f"✅ Git găsit: {git_path}")

    # Verifică directorul sursă
    if not os.path.exists(SOURCE_DIR):
        print(f"❌ Directorul sursă nu există: {SOURCE_DIR}")
        return

    # Contează template-urile
    template_count = len([item for item in os.listdir(SOURCE_DIR) if os.path.isdir(os.path.join(SOURCE_DIR, item))])
    file_count = len([item for item in os.listdir(SOURCE_DIR) if os.path.isfile(os.path.join(SOURCE_DIR, item))])

    print(f"📊 Conținut detectat:")
    print(f"   📂 {template_count} foldere template")
    print(f"   📄 {file_count} fișiere")

    # Confirmă
    response = input(f"\n❓ Continui cu upload-ul complet? (y/N): ").lower()
    if response != 'y':
        print("⏹️  Anulat.")
        return

    start_time = time.time()

    try:
        # Creează directorul de lucru
        os.makedirs(WORK_DIR, exist_ok=True)
        print(f"\n📁 Director de lucru: {WORK_DIR}")

        # Creează repository pe GitHub
        if not create_github_repo():
            return

        # Copiază conținutul
        copy_all_content()

        # Upload pe GitHub
        if upload_to_github(git_path):
            total_time = time.time() - start_time

            print(f"\n🎉 UPLOAD COMPLET!")
            print("=" * 60)
            print(f"✅ Repository creat: https://github.com/{USERNAME}/{REPO_NAME}")
            print(f"⏱️  Timp total: {total_time/60:.1f} minute")
            print(f"📊 Conținut: {template_count} template-uri + fișiere")

            print(f"\n🌐 Acces rapid:")
            print(f"   🔗 Repository: https://github.com/{USERNAME}/{REPO_NAME}")
            print(f"   📖 README: https://github.com/{USERNAME}/{REPO_NAME}#readme")
            print(f"   🎨 Template Browser: https://{USERNAME}.github.io/{REPO_NAME}/")

        else:
            print("❌ Upload eșuat!")

    except Exception as e:
        print(f"❌ Eroare generală: {e}")

    finally:
        # Cleanup
        cleanup()

if __name__ == "__main__":
    main()