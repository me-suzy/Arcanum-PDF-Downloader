import requests

# ÎNLOCUIEȘTE CU TOKEN NOU
NEW_TOKEN = "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"  # Token nou aici

def test_new_token():
    """Testează noul token"""
    headers = {
        "Authorization": f"token {NEW_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

    print("🔐 Testez noul token...")

    # Test user
    response = requests.get("https://api.github.com/user", headers=headers)

    if response.status_code == 200:
        user_data = response.json()
        print(f"✅ Token valid!")
        print(f"   👤 User: {user_data['login']}")
        return True
    else:
        print(f"❌ Token invalid: {response.status_code}")
        print(f"   Răspuns: {response.json()}")
        return False

def main():
    print("🔄 REFRESH TOKEN GITHUB")
    print("=" * 30)

    if NEW_TOKEN == "ghp_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX":
        print("❌ CONFIGUREAZĂ TOKEN-UL NOU!")
        print("\n📋 PAȘI:")
        print("   1. Mergi la: https://github.com/settings/tokens")
        print("   2. Delete token-ul vechi")
        print("   3. Generate new token (classic)")
        print("   4. Selectează permisiunea 'repo'")
        print("   5. Copiază token-ul în script")
        return

    if test_new_token():
        print(f"\n✅ Token funcționează!")
        print(f"📝 Înlocuiește în script-ul principal:")
        print(f'   TOKEN = "{NEW_TOKEN}"')
    else:
        print(f"\n❌ Token-ul nu funcționează")

if __name__ == "__main__":
    main()